package fr.ucaolan.xmen;

import android.app.Application;
import android.content.res.Resources;
import android.content.res.TypedArray;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class XMenApplication extends Application {
    //variable globale de l'application : la liste des XMen
    private final List<XMen> liste=new ArrayList<>();

    public List<XMen> getListe() {
        return liste;
    }

    //initialisation du contexte
    @Override public void onCreate()
    {
        super.onCreate();
        //TODO initialiser la liste à partir des ressources, voir les explications

        //acces  aux ressources
        Resources res=getResources();
        final String[] noms=res.getStringArray(R.array.noms);
        final String[] alias=res.getStringArray(R.array.alias);
        final String[] descriptions=res.getStringArray(R.array.descriptions);
        final String[] pouvoirs=res.getStringArray(R.array.pouvoirs);
        TypedArray images= getResources().obtainTypedArray(R.array.idimages);
        for(int i=0;i<noms.length;i++)
        {
            //constructeur avec tous les paramètres
            XMen xmen=new XMen(
                    noms[i],
                    alias[i],
                    descriptions[i],
                    pouvoirs[i],
                    images.getResourceId(i,R.drawable.undef) );
            //ajout du xmen à la liste
            liste.add(xmen);
        }
        //libérer certaines ressources explicitement
        images.recycle();
    }

}
