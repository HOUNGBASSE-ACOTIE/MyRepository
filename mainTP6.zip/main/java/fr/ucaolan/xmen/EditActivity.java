package fr.ucaolan.xmen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.List;

import fr.ucaolan.xmen.databinding.ActivityEditBinding;

public class EditActivity extends AppCompatActivity {

    private ActivityEditBinding ui;
    private List<XMen> liste;

    static final String EXTRA_POSITION = "position";

     // variable pour stocker la position du XMen

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ui = ActivityEditBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());

        //obtenir la liste
        XMenApplication application=(XMenApplication) getApplication();
        liste=application.getListe();

        //récupérer la position du xmen qui se trouve dans l'intent
        Intent intent = getIntent();
        int position  = intent.getIntExtra(EXTRA_POSITION, -1);

        if (position <liste.size() && position != -1) {
            XMen xmen = liste.get(position);
            setXMen(xmen);
        }
        /* si je ne fais pas position<liste.size , lorsaue j'appuyerai sur le menu pour créer un autre xmen ça va cracher car la taille qui était normalement
        * de 20 va devenir 21 et liste.get(position) va retourner 21 qui n'existe puisque liste.size() = 20  */

    }

    //premiere des methodes qui gèrent les menus
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.edit_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    public void onAccept(MenuItem item)
    {

        /* pour mettre à jour le personnage courant au lieu de créer un nouveau personnage lorsque l'utilisateur
        sélectionne le menu d'option accept, vous pouvez utiliser la même logique que dans la méthode onCreate()
        pour récupérer la position du XMen courant à partir de l'extra dans l'intent, et vérifier si la position
        est valide ou non. Si la position est valide, vous pouvez mettre à jour les propriétés du XMen correspondant
        avec les nouvelles valeurs saisies par l'utilisateur*/

        Intent intent = getIntent();
        int position  = intent.getIntExtra(EXTRA_POSITION, -1);

        if (position <liste.size() && position != -1) {
            //récupérer le XMen à modifier
            XMen xmen = liste.get(position);

            //mettre à jour les propriétés du XMen avec les nouvelles valeurs saisies
            xmen.setNom(ui.nom.getText().toString());
            xmen.setAlias(ui.alias.getText().toString());
            xmen.setDescriptions(ui.descriptions.getText().toString());
            xmen.setPouvoirs(ui.pouvoirs.getText().toString());

            //terminer l'activité en indiquant un succès
            setResult(RESULT_OK);
            finish();
        } else {
            //créer un xmen avec les informations saisies par l'utilisateur
            XMen xmen = new XMen();
            xmen.setNom(ui.nom.getText().toString());
            xmen.setAlias(ui.alias.getText().toString());
            xmen.setDescriptions(ui.descriptions.getText().toString());
            xmen.setPouvoirs(ui.pouvoirs.getText().toString());
            //xmen.setNom(ui.image.getImage());

            //ajouter le xmen dans la liste
            liste.add(xmen);

            //terminer l'activité en indiquant un succès
            setResult(RESULT_OK);
            finish();

        }

    }
    private void setXMen(XMen xmen)
    {
        //mettre les infos du xmen dans les vues
        ui.nom.setText(xmen.getNom());
        ui.alias.setText(xmen.getAlias());
        ui.descriptions.setText(xmen.getDescriptions());
        ui.pouvoirs.setText(xmen.getPouvoirs());
        ui.image.setImageResource(xmen.getIdImage());
    }
}