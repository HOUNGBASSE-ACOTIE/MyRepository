package fr.ucaolan.xmen;

import static fr.ucaolan.xmen.EditActivity.EXTRA_POSITION;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.List;

import fr.ucaolan.xmen.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    //interface utilisateurs
    private ActivityMainBinding ui;
    private List<XMen> liste;
    private XMenAdapter adapter;

    private ActivityResultLauncher<Intent> editLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       ui=ActivityMainBinding.inflate(getLayoutInflater());
       setContentView(ui.getRoot());
        //setTitle(getLocalClassName());

       //obtenir la liste
       XMenApplication application=(XMenApplication) getApplication();
       liste=application.getListe();

        //creer l'adaptateur
        adapter=new XMenAdapter(liste);

        //fournir l'adaptateur au recycler
        ui.recycler.setAdapter(adapter);

        //dimensions constantes
        ui.recycler.setHasFixedSize(true);

        //layout manager
        RecyclerView.LayoutManager lm= new LinearLayoutManager(this);
        ui.recycler.setLayoutManager(lm);

        //separateur
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        ui.recycler.addItemDecoration(dividerItemDecoration);

        //onCreate va fournir un onItem... à l'adaptateur qui le fournira à chaque viewholder
        adapter.setOnItemClickListener(this::onItemClick);

        editLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), this::onEditActivityFinished);


    }

    private void onItemClick(int position) {
        //recuperer le xmen concerne
        XMen xmen = liste.get(position);
        //changer l'image du x-men
        xmen.setIdImage(R.drawable.undef);

        //signaler à l'adapter que l'élément a changé
        adapter.notifyItemChanged(position);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        XMenApplication application=(XMenApplication)getApplication();
        //selon l'item selectionné
        int iditem= item.getItemId();
        if(iditem==R.id.reinit)
        {
            //vider la liste
            application.initListe();
            // signaler le changement à l'adapter
            adapter.notifyDataSetChanged();
            return true;
        }
        if(iditem==R.id.create)
        {
            onEdit(liste.size()); // appeler onEdit avec le numéro du XMen à éditer
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void onEdit(int position)
    {
        Intent intent=new Intent(this,EditActivity.class);
        intent.putExtra(EXTRA_POSITION, position); // ajouter l'extra "position"
        editLauncher.launch(intent);
    }

    @SuppressLint("NotifyDataSetChanged")
    private void onEditActivityFinished(ActivityResult result)
    {
        if(result.getResultCode()==RESULT_OK)
        {
            //prevenir l'adaptateur que la liste a changé
            adapter.notifyDataSetChanged();
        }
    }

    //ajout de l'ecouteur pour les clics sur les items du menu contextuels
    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        //recupérer la position de l'élément concerné par le menu (dans order)
        int position=item.getOrder();

        //selon le bouton de menu
        switch (item.getItemId())
        {
            case XMenViewHolder.MENU_EDIT:
                onEdit(position);
                return true;
            case XMenViewHolder.MENU_DELETE:
                onDelete(position);
                return true;
        }
        return super.onContextItemSelected(item);
    }

    private void onReallyDelete(int position)
    {
        liste.remove(position);
        //signaler à l'adapteur que cette position été supprimer
        adapter.notifyItemRemoved(position);
    }

    //dialogue de confirmation de suppression
    private void onDelete(int position)
    {
        XMen xMen=liste.get(position);
        new AlertDialog.Builder(this)
                .setTitle(xMen.getNom())
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setMessage("Vous confirmer la suppression ? ")
                //le bouton oui supprime vraiment
                .setPositiveButton(android.R.string.ok,(dialog,idbtn)->onReallyDelete(position))
                //le bouton non , ne fait rien
                .setNegativeButton(android.R.string.cancel,null)
                //affichage du dialog
                .show();
    }

}