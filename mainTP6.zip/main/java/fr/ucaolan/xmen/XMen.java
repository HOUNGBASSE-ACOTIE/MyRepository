package fr.ucaolan.xmen;

import android.annotation.SuppressLint;

import androidx.annotation.DrawableRes;

@SuppressWarnings("unused")
public class XMen {
    //variables representant les informations
    private String nom;
    private String alias;
    private String descriptions;
    private String pouvoirs;
    //TODO ajouter les champs manquant : alias , ...

    /* L’annotation @DrawableRes permet au compilateur d’être certain que ce qu’on affecte est bien
       l’identifiant d’une ressource de type drawable.*/
    private @DrawableRes int idImage;

    public XMen( String nom, String alias, String descriptions, String pouvoirs, @DrawableRes int idImage) {
        this.nom = nom;
        this.alias = alias;
        this.descriptions = descriptions;
        this.pouvoirs = pouvoirs;
        this.idImage = idImage;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setAlias( String alias) {
        this.alias = alias;
    }

    public void setDescriptions( String description) {
        this.descriptions = descriptions;
    }

    public void setPouvoirs(String pouvoirs) {
        this.pouvoirs = pouvoirs;
    }

    public void setIdImage(@DrawableRes int idImage) {
        this.idImage = idImage;
    }

    public String getNom() {
        return nom;
    }

    public String getAlias() {
        return alias;
    }

    public String getDescriptions() {
        return descriptions;
    }

    public String getPouvoirs() {
        return pouvoirs;
    }

    public @DrawableRes int getIdImage() {
        return idImage;
    }

    //constructeur sans paramètre
    public XMen()
    {
        nom="inconnu";
        this.idImage=R.drawable.undef;
    }
}
