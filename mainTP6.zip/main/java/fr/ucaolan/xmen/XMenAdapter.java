package fr.ucaolan.xmen;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fr.ucaolan.xmen.databinding.XMenBinding;

public class XMenAdapter extends RecyclerView.Adapter<XMenViewHolder> {



    private XMenAdapter.OnItemClickListener onItemClickListener;
    private List<XMen> liste;
    @NonNull
    @Override
    public XMenViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        XMenBinding ui=XMenBinding.inflate(LayoutInflater.from( parent.getContext() ) , parent , false);
        return new XMenViewHolder(ui);
    }

    @Override
    public void onBindViewHolder(@NonNull XMenViewHolder holder, int position) {
        holder.setXMen(liste.get(position));
        //fournir l'ecouteur de l'adapteur au viewholder
        holder.setOnItemClickListener(onItemClickListener);
        //onItem... sera mainactivity mais c'est elle même qui s'enregistrera
    }

    @Override
    public int getItemCount() {
        return liste.size();//pour retourner la taille de la liste
    }

    public XMenAdapter(List<XMen> liste) {
        this.liste = liste;
    }

    public interface OnItemClickListener
    {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

}
