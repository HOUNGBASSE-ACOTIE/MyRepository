package fr.ucaolan.xmen;

import android.view.ContextMenu;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import fr.ucaolan.xmen.databinding.XMenBinding;

public class XMenViewHolder extends RecyclerView.ViewHolder {
    private final XMenBinding ui;


    private XMenAdapter.OnItemClickListener onItemClickListener;

    public static final int MENU_EDIT=1;
    public static final int MENU_DELETE=2;
    public XMenViewHolder(@NonNull XMenBinding ui )
    {
        super(ui.getRoot());
        this.ui=ui;
        //pour dire qu'on lui a clique dessus
        itemView.setOnClickListener(this::onClick);

        // pour ajouter l'écouteur de clics longs
        itemView.setOnCreateContextMenuListener(this::onCreateContextMenu);
    }
    public void setXMen(XMen xmen)
    {
        ui.nom.setText(xmen.getNom());
        ui.alias.setText(xmen.getAlias());
        ui.description.setText(xmen.getDescriptions());
        ui.pouvoirs.setText(xmen.getPouvoirs());
        ui.image.setImageResource(xmen.getIdImage());
    }

    public void setOnItemClickListener(XMenAdapter.OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    private void onClick(View v)
    {
        if(onItemClickListener!=null)//test par precaution
        {
            onItemClickListener.onItemClick(getAdapterPosition());
        }
    }

    public void onCreateContextMenu(ContextMenu menu,View v,ContextMenu.ContextMenuInfo menuInfo )
    {
        //position du xmen concerné
        int position=getAdapterPosition();
        //titre du menu = nom du xmen
        menu.setHeaderTitle(ui.nom.getText());
        //utiliser "order" 3eme param pour stocker la position du xmen
        menu.add(0,MENU_EDIT,position,"Edit");
        menu.add(0,MENU_DELETE,position,"Delete");
    }
}
