package com.example.coach.controleur;
import  com.example.coach.modele.Profil;

//utilisation du pattern singleton
public final class Controle//final parce qu'on ne veut pas qu'une autre classe hérite d'elle
{
    private static Controle instance=null;
    private Profil profil;
    private Controle()//private parce que je ne veux pas créer plusieurs instances
    {
        super();//il n'y a pas de classe mère (mais de base ,toutes les classes héritent de Object donc rien ne va se passer mais bon
    }

    public static Controle getInstance()//methode qui va permettre de remplir l'instance une seule fois
    {
        if(Controle.instance==null)// ie que si l'instance n'est pas encore générée , ...
        {
            Controle.instance=new Controle();//on l'a génère
        }
        return Controle.instance;
        //l'instance est unique , elle n'est pas créee 2 fois
    }

    /** Documentation technique
     *creation du profil
     * @param poids
     * @param taille en cm
     * @param age
     * @param sexe 1 pour homme 0 pour femme
     */

    public void creerProfil(Integer poids,Integer taille,Integer age,Integer sexe)
    {
        profil=new Profil(poids,taille,age,sexe);
    }
    public float getImg()
    {
        return profil.getImg();
    }
    public String getMessage()
    {
        return profil.getMessage();
    }
}
