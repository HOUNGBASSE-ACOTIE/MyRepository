package com.example.coach.outils;

import android.content.Context;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;

public  abstract  class Serializer {

    /**
     * Serialisation d'un objet
     * @param filename
     * @param object
     */
    public static void serialize(String filename , Object object , Context context)//va  de memoriser un objet dans un fichier binaire
    {
        try
        {
            FileOutputStream file=context.openFileOutput(filename,context.MODE_PRIVATE);
            ObjectOutputStream oos;//onen  cree un flux en output pour pouvoir écrir dans le fichier
            try
            {
                oos=new ObjectOutputStream(file);
                oos.writeObject(object);//on écrir grâce au flux , l'objet recuperé en paramètre
                oos.flush();
                oos.close();
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
        }
        catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Deserialisation d'un objet
     * @param filename
     * @param context
     * @return
     */
     public static Object deSerialize(String filename,Context context) // va permettre de récupérer cet objet
     {
         try
         {
             FileInputStream file=context.openFileInput(filename);
             ObjectInputStream ois;
             try
             {
                 ois=new ObjectInputStream(file);
                 try
                 {
                    Object object=ois.readObject();
                    ois.close();
                    return object;
                 }
                 catch (ClassNotFoundException e)
                 {
                    e.printStackTrace();
                 }
             }
             catch(StreamCorruptedException e)
             {
                e.printStackTrace();
             }
             catch (IOException e)
             {
                 e.printStackTrace();
             }
         }
         catch (FileNotFoundException e)
         {
            e.printStackTrace();
         }
         return null;
     }
}

//6 : 56





















