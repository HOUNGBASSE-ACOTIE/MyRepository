package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.example.tp4.databinding.ActivityInfosBinding;

public class InfosActivity extends AppCompatActivity {
    private ActivityInfosBinding ui;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ui=ActivityInfosBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        setTitle(getLocalClassName());
        ui.bouton1.setOnClickListener(this::onBouton1Click);
    }
    public void onBouton1Click(View view)
    {
        finish();
    }
}