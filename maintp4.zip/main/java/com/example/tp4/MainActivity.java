package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.os.Bundle;
import android.view.View;
import com.example.tp4.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {

    //--------------------------------------------------------------------
    private static final String TAG ="TP4";
   // private TextView txtView;
   private ActivityMainBinding ui;
   //private int compteur;

    //-------------------------------------------------------------------------
    private TP4Apllication app;
    int compteur;

    //---------------------------------------------------------------------------

    /* @Override indique que la méthode concernée doit impérativement exister dans la superclasse, donc que c’est véritablement une surcharge.*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //mise en place du layout par un view binding
        ui=ActivityMainBinding.inflate(getLayoutInflater());
        //setContentView(R.layout.activity_main);
        setContentView(ui.getRoot());
        //Titre de l'activité
        setTitle(getLocalClassName());
        //message d'information
        Log.i(TAG, "dans "+getLocalClassName()+" .onCreate");

       /* txtView=findViewById(R.id.texte);//Récupération du TextView qui a pour identifiant "texte"
        txtView.setText("Bonjour");//Modification du texte */

       // ui.texte.setText("Voici MainActivity");

        //°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
        app=(TP4Apllication) getApplicationContext();
        compteur=app.getCompteur();

        //°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°

        //Définition d’un écouteur privé anonyme
        ui.bouton2.setOnClickListener(btn->{
            compteur+=2;
            app.setCompteur(compteur);
            ui.texte.setText("compteur= "+compteur);
        });

        //--------------------------------------------------------------------------

        /*ui.bouton2.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              compteur += 2;
              ui.texte.setText("compteur= "+compteur);
          }
      }); */

        //-------------------------------------------------------------------------

        ui.bouton3.setOnClickListener(this::onBouton3Click);

        ui.bouton4.setOnClickListener(this);

        ui.bouton5.setOnClickListener(this::onBouton5Click);

        ui.bouton6.setOnClickListener(this::onBouton6Click);

        ui.bouton7.setOnClickListener(this::onBouton7Click);

        //-------------------------------------------------------------------------

        Intent intent=getIntent();
        String username=intent.getStringExtra("username");
        ui.texte.setText("Bonjour "+username);

        //------------------------------------------------------------------------
    }
    //*******************************************************************************************************

    //-------------------------------------------------------------------------------------------------------

    //Définition d’un écouteur par ajout d’un attribut dans le layout (android:onClick="onBouton1Click")
    public void onBouton1Click(View view)
    {
        compteur+=1;
        app.setCompteur(compteur);
        ui.texte.setText("compteur= "+compteur);
    }

    //----------------------------------------------------------------------------------------------------

    //Définition d’un écouteur privé anonyme (ecouteur avec référence de methode
    private void onBouton3Click(View view)
    {
        compteur *= 2;
        app.setCompteur(compteur);
        ui.texte.setText("compteur= "+compteur);
    }

    //---------------------------------------------------------------------------------------------------

    //L’activité en tant qu’écouteur (implements View.OnClickListener)
    @Override
    public void onClick(View view)
    {
        compteur *= 5;
        app.setCompteur(compteur);
        ui.texte.setText("compteur= "+compteur);
    }

    //--------------------------------------------------------------------------------------------------
    private void onBouton5Click(View view)
    {
        Intent intent=new Intent(this,InfosActivity.class);
        startActivity(intent);
    }

    //---------------------------------------------------------------------------------------------------

    private void onBouton6Click(View view)
    {
        Intent intent=new Intent(this,InfosActivity.class);
        startActivity(intent);
        finish();
    }

    //---------------------------------------------------------------------------------------------------

    private void onBouton7Click(View view )
    {
        String url="https://perso.univ-rennes1.fr/pierre.nerzic/Android";
        Intent intent= new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

    //--------------------------------------------------------------------------------------------------

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.i(TAG, "dans "+getLocalClassName()+" .onDestroy");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.i(TAG, "dans "+getLocalClassName()+" .onPause");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.i(TAG, "dans "+getLocalClassName()+" .onResume");
    }

    //-------------------------------------------------------------------------------------------------
}