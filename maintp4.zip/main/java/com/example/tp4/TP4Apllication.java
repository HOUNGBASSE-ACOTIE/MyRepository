package com.example.tp4;

import android.app.Application;

public class TP4Apllication extends Application {
    private int compteur ;

    @Override
    public void onCreate() {
        super.onCreate();
        this.compteur=0;
    }

    public int getCompteur() {
        return compteur;
    }

    public void setCompteur(int compteur) {
        this.compteur = compteur;
    }
}
